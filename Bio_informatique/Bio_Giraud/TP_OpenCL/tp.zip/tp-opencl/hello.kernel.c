

__kernel void square(
   float* input,
   float* output,
   const unsigned int count)
{    
  int i = get_global_id(0);
  if(i < count) 
     output[i] = input[i] * input[i]
}


