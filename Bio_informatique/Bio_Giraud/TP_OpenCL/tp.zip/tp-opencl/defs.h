

#define DATA_SIZE (1600) 
#define LOCAL 160


