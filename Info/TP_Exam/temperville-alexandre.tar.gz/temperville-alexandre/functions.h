# ifndef FUNCTIONS_H
# define FUNCTIONS_H
# include "pp.h"

extern int indent(FILE*);
extern int brace1_command(FILE*);
extern int brace2_command(FILE*);


# endif /* FUNCTIONS_H */
