#!/bin/bash

find -type f -name "_*" -exec rm {} \;
find -type f -name "*.o" -exec rm {} \;
rm -f pp
