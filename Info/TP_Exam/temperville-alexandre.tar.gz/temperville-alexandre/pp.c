# include "pp.h"
# include "functions.h"


int main()
{

/* ===================================================================
                            DECLARATIONS
==================================================================== */

  char *file1, file2[N]="_";
  int c;
  FILE *fp1=NULL;
  FILE *fp2=NULL;
  cnt=0;
  com=0;
  w=BEGINNING_LINE;
  file1=(char*) malloc((N+1)*sizeof(char));

/* ===================================================================
                          OPENING OF FILES
==================================================================== */

  printf("In what file you want to apply the pretty printer ?\n");
  scanf("%s", file1);
  strcat(file2, file1);
  fp1=fopen(file1, "r");
  fp2=fopen(file2, "w");
  c=fgetc(fp1);
  
/* ===================================================================

                   LOOP   (analysis each character of a
                          file and modifies it in consequence)

==================================================================== */

  while (c != EOF)
    {
      switch (w)
	{

/* ===================================================================
                BEGINNING_LINE ('\n' has been read)
==================================================================== */

	case BEGINNING_LINE:
	  switch (c)
	    {
      	    case '/':
	      w=BEGINNING_COMMENT;
	      break;
	    case ' ':
	      break;
	    case '\n':
	      break;
	    case '\t':
	      break;
	    case '{':
	      putc('\n', fp2);
	      w=brace1_command(fp2);
	      break;
	    case '}':
	      putc('\n', fp2);
	      w=brace2_command(fp2);
	      break;
	    case '#':
	      putc(c, fp2);
	      w=MACRO;
	      break;
	    case '"':
	      putc(c, fp2);
	      w=CHAIN;
	      break;
	    default:
	      putc(c, fp2);
	      w=MIDDLE_LINE;
	      break;
	    }
	  break;
	  
/* ===================================================================
                          MIDDLE_LINE
==================================================================== */
	  
	case MIDDLE_LINE:
	  switch (c)
	    {
	    case '"':
	      putc(c, fp2);
	      w=CHAIN;
	      break;
            case ' ':
              putc(c, fp2);
              w=END_WORD;
              break;
	    case '/':
	      w= BEGINNING_COMMENT;
	      break;
	    case '\n':
	      putc(c, fp2);
	      indent(fp2);
	      w=BEGINNING_LINE;
	      break;
	    case '{':
	      putc('\n', fp2);
	      w=brace1_command(fp2);
	      break;
	    case '}':
	      putc('\n', fp2);
	      w=brace2_command(fp2);
	      break;
	    case ';':
	      fputs(";\n", fp2);
	      w=BEGINNING_LINE;
	      break;
	    default:
	      putc(c, fp2);
	      break;
	    }
	  break;

/* ===================================================================
                  END_WORD (' ' has been read in a MIDDLE_LINE)
==================================================================== */

	case END_WORD:
	  switch (c)
	    {
	    case '"':
	      putc(c, fp2);
	      w=CHAIN;
	      break;
	    case '/':
	      w= BEGINNING_COMMENT;
	      break;
	    case '\n':
	      putc(c, fp2);
	      indent(fp2);
	      w=BEGINNING_LINE;
	      break;
	    case '{':
	      putc('\n', fp2);
	      w=brace1_command(fp2);
	      break;
	    case '}':
	      putc('\n', fp2);
	      w=brace2_command(fp2);
	      break;
	    case ';':
	      fputs(";\n", fp2);
	      w=BEGINNING_LINE;
	      break;
            case ' ':
              break;
            case '\t':
              break;
	    default:
	      putc(c, fp2);
	      break;
	    }
	  break;

/* ===================================================================
                 BEGINNING_COMMENT ('/' has been read)
==================================================================== */

	case BEGINNING_COMMENT:
	  switch (c)
	    {
	    case '\n':
	      fputs("/\n", fp2);
	      indent(fp2);
	      w=BEGINNING_LINE;
	      break;
	    case '{':
	      fputs("/\n", fp2);
	      w=brace1_command(fp2);
	      break;
	    case '}':
	      fputs("/\n", fp2);
	      w=brace2_command(fp2);
	      break;
	    case '/':
	      putc('*', fp2);
              w=COMMENT;
	      break;
	    case '*':
	      putc('\n', fp2);
	      indent(fp2);
	      fputs("/*", fp2);
	      com++;
	      w=PLUS_COMMENT;
	      break;
	    case '"':
	      putc('/', fp2);
	      putc('"', fp2);
	      w=CHAIN;
	      break;
	    default:
	      putc('/', fp2);
	      putc(c, fp2);
	      w=MIDDLE_LINE;
	      break;
	    }
	  break;

/* ===================================================================
              COMMENT    (we are in a comment, '/' then '*' have
                        been read maybe not at the previous step)
==================================================================== */

	case COMMENT:
	  switch (c)
	    {
	    case '\n':
	      fputs("*/\n", fp2);
	      indent(fp2);
	      fputs("/*", fp2);
	      w=BEGINNING_SPACES_COMMENT;
	      break;
	    case '*':
	      w=END_COMMENT;
              break;
	    default:
	      putc(c, fp2);
	      break;
	    }
	  break;

/* ===================================================================
                  PLUS_COMMENT ("//" has been read)
==================================================================== */

	case PLUS_COMMENT:
	  switch (c)
	    {
	    case '\n':
	      fputs("*/\n", fp2);
	      indent(fp2);
	      w=BEGINNING_LINE;
	      break;
	    default:
	      putc(c, fp2);
	      break;
	    }
	  break;

/* ===================================================================
          BEGINNING_SPACES_COMMENT ('/' then '*' have been read)
==================================================================== */

	case BEGINNING_SPACES_COMMENT:
	switch (c)
	  {
	  case ' ':
	    break;
	  case '\t':
	    break;
	  case '\n':
	    break;
	  default : 
	    putc(c, fp2);
	    w=COMMENT;
	    break;
	  }
	break;

/* ===================================================================
                      ENDCOMMENT ('*' has been read)
==================================================================== */

	case END_COMMENT:
	  switch (c) 
	    {
	    case '*':
	      putc('*', fp2);
	      break;
	    case '/':
	      fputs("*/\n", fp2);
	      indent(fp2);
	      com--;
	      w=BEGINNING_LINE;
	      break;
	    default:
	      putc('*', fp2);
	      putc(c, fp2);
	      w=COMMENT;
	      break;
	    }
	  break;
      
/* ===================================================================
                      CHAIN ('"' has been read)
==================================================================== */
	case CHAIN:
	  switch (c)
	    {
	    case '"':
	      putc(c, fp2);
	      w=MIDDLE_LINE;
	      break;
	    default:
	      putc(c, fp2);
	      break;
	    }
	  break;


/* ===================================================================
                      MACRO ('#' has been read)
==================================================================== */
	case MACRO:
	  switch (c)
	    {
             putc(' ', fp2);
            case  ' ':
              break;
	    case '\n':
	      putc('\n', fp2);
	      indent(fp2);
	      w=BEGINNING_LINE;
	      break;
	    case '/':
	      w=BEGINNING_COMMENT;
	      break;
	    default:
	      putc(c, fp2);
	      break;
	    }

	}
c=fgetc(fp1);
    }

/* ===================================================================
                             ERRORS
==================================================================== */
  
  if ((com != 0) && (cnt != 0))
    {
      printf("Be careful, %d opened brace(s) and %d opened comment(s) are not closed.\n", cnt, com);
      exit(EXIT_FAILURE);
    }
  if ((com == 0) && (cnt != 0))
    {
      printf("Be careful, %d opened brace(s) are not closed.\n", cnt);
      exit(EXIT_FAILURE);
    }
  if ((com != 0) && (cnt == 0))
    {
      printf("Be careful, %d opened comment(s) are not closed.\n", com);
      exit(EXIT_FAILURE);    }


/* ===================================================================
                          END OF THE FILE
==================================================================== */
  fclose(fp1);
  fclose(fp2);
  free(file1);

  return 0;
}   
      
