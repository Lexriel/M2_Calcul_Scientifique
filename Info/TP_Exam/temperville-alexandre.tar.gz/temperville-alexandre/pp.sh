#!/bin/bash

myls()
{
    local i
    for i in "$@"
    do
  if [ -d "$i" ]
  then
      echo "Entering in directory $i"
      cd "$i"
      myls *
      echo "Leaving directory $i"
      cd ..
  else
      echo "$i"
  fi
      done
}

case $1 in
    -l) rm file1
        rename '_*' * ;;

    -r)  if [ $# -eq 0 ]
         then
             read A
             myls $A
         else
             myls "$@"
         fi ;;

    -rf) rm file1
         rename '_*' *

         if [ $# -eq 0 ]
         then
             read A
             myls $A
         else
             myls "$@"
         fi ;;
